<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('order_number')->unique();
            $table->decimal('total_amount', 12, 2);
            $table->string('status')->default('pending'); // pending, paid, failed
            $table->string('payment_method'); // card, mpesa, airtel
            $table->string('mpgs_session_id')->nullable();
            $table->json('items')->nullable(); // Stores the cart data
            $table->json('customer')->nullable();
            $table->json('delivery')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};